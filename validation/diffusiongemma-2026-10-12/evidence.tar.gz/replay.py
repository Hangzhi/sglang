"""Run the PR's committed endpoint replay tests against the already-running server."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

path = Path('/home/ubuntu/sglang/test/registered/e2e/dllm/test_diffusiongemma_decisions.py')
spec = importlib.util.spec_from_file_location('diffusiongemma_committed_e2e', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cls = module.TestDiffusionGemmaDecisions
cls.base_url = 'http://127.0.0.1:30000'
cls.setUpClass = classmethod(lambda cls: None)
cls.tearDownClass = classmethod(lambda cls: None)
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
if len(sys.argv) > 1:
    Path(sys.argv[1]).write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful()},indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
