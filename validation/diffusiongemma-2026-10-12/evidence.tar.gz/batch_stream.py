import json
from pathlib import Path
import sys
import httpx

root = Path(sys.argv[1])
rows = json.loads((root/'raw-smoke.json').read_text())['records'][:2]
with httpx.Client(base_url='http://127.0.0.1:30000',timeout=300) as client:
    body = {'text':[r['prompt'] for r in rows], 'return_logprob':True,
            'token_ids_logprob':[r['label_ids'] for r in rows],
            'sampling_params':{'max_new_tokens':5,'ignore_eos':True}}
    response = client.post('/generate',json=body)
    response.raise_for_status()
    batch = response.json()
    assert len(batch)==2
    for data,row in zip(batch,rows):
        assert data['output_ids'][:4]==[100,45518,107,101]
        assert len(data['meta_info']['output_token_ids_logprobs'])==5
        assert [item[1] for item in data['meta_info']['output_token_ids_logprobs'][4]]==row['label_ids']
    body.update(text=rows[0]['prompt'],token_ids_logprob=rows[0]['label_ids'],stream=True)
    events=[]
    with client.stream('POST','/generate',json=body) as response:
        response.raise_for_status()
        for line in response.iter_lines():
            if line.startswith('data: ') and line!='data: [DONE]':events.append(json.loads(line[6:]))
    final=events[-1]
    assert final['output_ids']==rows[0]['response']['output_ids']
    assert len(final['meta_info']['output_token_ids_logprobs'])==5
    for got,want in zip(final['meta_info']['output_token_ids_logprobs'],rows[0]['response']['meta_info']['output_token_ids_logprobs']):
        for a,b in zip(got,want):
            assert a[1]==b[1] and abs(a[0]-b[0])<2e-4,(a,b)
    (root/'batch-stream.json').write_text(json.dumps({'passed':True,'batch':batch,'stream':events},indent=2))
    print('PASS: mixed candidate lists in a real batch; streaming preserves every logprob row and matches non-streaming scores.')
