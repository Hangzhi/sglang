import argparse
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('--graphs', action='store_true')
parser.add_argument('--max-running', type=int, default=4)
args = parser.parse_args()
(ROOT / 'renoise.json').write_text(json.dumps({'seed': 42}))
cmd = [str(ROOT / 'venv/bin/python'), '-m', 'sglang.launch_server',
       '--model-path', '/home/ubuntu/models/diffusiongemma-26B-A4B-it',
       '--served-model-name', 'google/diffusiongemma-26B-A4B-it',
       '--dllm-algorithm', 'Gemma4Renoise', '--dllm-algorithm-config', str(ROOT / 'renoise.json'),
       '--trust-remote-code', '--dtype', 'bfloat16', '--attention-backend', 'triton',
       '--context-length', '8192', '--max-running-requests', str(args.max_running), '--mem-fraction-static', '0.85',
       '--cuda-graph-backend-prefill', 'disabled', '--host', '127.0.0.1', '--port', '30000']
cmd += ['--cuda-graph-bs-decode', *(['1', '2', '4'] if args.max_running >= 4 else ['1'])] if args.graphs else ['--no-dllm-fdfo', '--cuda-graph-backend-decode', 'disabled']
env = dict(os.environ, PYTHONPATH='/home/ubuntu/sglang/python', PYTHONUNBUFFERED='1',
           OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', SGLANG_ENABLE_HEALTH_ENDPOINT_GENERATION='0')
env['PATH'] = str(ROOT / 'venv/bin') + ':' + env['PATH']
with (ROOT / 'logs' / (args.name + '-server.txt')).open('w') as log:
    process = subprocess.Popen(cmd, env=env, cwd='/home/ubuntu/sglang', stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
record = {'pid': process.pid, 'command': cmd, 'git_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd='/home/ubuntu/sglang', text=True).strip()}
(ROOT / (args.name + '-launch.json')).write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
