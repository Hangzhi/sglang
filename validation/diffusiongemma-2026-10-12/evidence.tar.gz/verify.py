"""Native SGLang checks on the reference project's frozen data; no readout patch."""
import argparse
import base64
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import time

import httpx
import numpy as np

ROOT = Path(__file__).resolve().parent
REFERENCE = Path('/home/ubuntu/diffusion-jev-sglang')
MODEL = 'google/diffusiongemma-26B-A4B-it'
PREFIX = [100, 45518, 107, 101]

def read_json(path):
    return json.loads(path.read_text())

def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]

def image_url(path):
    mime = 'image/png' if path.suffix == '.png' else 'image/jpeg'
    return 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode()

def cases():
    result = []
    historical = read_json(REFERENCE / 'reports/diffusiongemma/jevbench/local-run.json')
    for split in ('easy', 'original', 'hard'):
        path = Path('/home/ubuntu/jevbench/datasets/public') / (split + '.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == historical['dataset_sha256'][split]
        for row in read_rows(path):
            result.append({'dataset': 'jevbench', 'id': row['id'], 'state': row['state'],
                           'question': row['question'], 'expected': row['expected'], 'labels': row['labels']})
    for dataset in ('emojify', 'tweeteval'):
        directory = REFERENCE / 'data/emoji-benchmark' / dataset
        manifest = read_json(directory / 'manifest.json')
        previous = read_json(REFERENCE / 'reports/diffusiongemma/emoji' / dataset / 'dataset.json')
        assert manifest['files']['test']['sha256'] == previous['files']['test']['sha256']
        for row in read_rows(directory / 'test.jsonl'):
            result.append({'dataset': dataset, 'id': row['id'], 'state': row['text'],
                           'question': manifest['question'], 'expected': row['label'], 'labels': manifest['labels']})
    manifest = read_json(REFERENCE / 'data/flowers/manifest.json')
    previous = read_rows(REFERENCE / 'reports/diffusiongemma/flowers/predictions.jsonl')
    selected = [r for r in manifest['images'] if r['benchmark']]
    assert {r['id'] for r in selected} == {r['id'] for r in previous}
    question = {'type': 'choice', 'instructions': 'Which type of flower is most prominent in the attached image?',
                'criteria': {'daisy':'A daisy flower', 'dandelion':'A dandelion flower or seed head', 'rose':'A rose flower', 'sunflower':'A sunflower', 'tulip':'A tulip flower'}}
    for row in selected:
        result.append({'dataset':'flowers', 'id':row['id'], 'state':'Classify the flower shown in the attached image.',
                       'question':question, 'expected':row['label'], 'labels':list(question['criteria']),
                       'image':str(REFERENCE / 'data/flowers/images' / (row['id']+'.jpg'))})
    return result

def post(client, route, body):
    response = client.post(route, json=body)
    if response.status_code != 200:
        raise RuntimeError(f'{route}: HTTP {response.status_code}: {response.text[:2000]}')
    return response.json()

def distribution(values):
    assert values and all(math.isfinite(v) and 0 <= v <= 1 for v in values)
    assert math.isclose(sum(values), 1, abs_tol=1e-5)

def raw_smoke(client, output):
    from transformers import AutoTokenizer
    sys.path.insert(0, str(REFERENCE / 'src'))
    from diffusion_jev.scoring import messages, options
    from diffusion_jev.schemas import Choice, Noul, Score
    tokenizer = AutoTokenizer.from_pretrained('/home/ubuntu/models/diffusiongemma-26B-A4B-it')
    all_cases = cases()
    selected = []
    for kind in ('choice','noul','score'):
        selected.append(next(row for row in all_cases if row['dataset']=='jevbench' and row['question']['type']==kind))
    selected += [next(row for row in all_cases if row['dataset']==dataset) for dataset in ('emojify','tweeteval','flowers')]
    records = []
    for row in selected:
        question = {'choice':Choice,'noul':Noul,'score':Score}[row['question']['type']](**row['question'])
        chat = messages(row['state'], question)
        if row.get('image'):
            chat[1]['content'] = [{'type':'image'}, {'type':'text','text':chat[1]['content']}]
        prompt = tokenizer.apply_chat_template(chat, tokenize=False, add_generation_prompt=True, enable_thinking=False)
        labels = [tokenizer.encode(chr(65+i), add_special_tokens=False)[0] for i in range(len(options(question)))]
        body = {'text':prompt, 'sampling_params':{'max_new_tokens':5,'ignore_eos':True},
                'return_logprob':True, 'token_ids_logprob':labels}
        if row.get('image'): body['image_data'] = [image_url(Path(row['image']))]
        start = time.perf_counter()
        data = post(client, '/generate', body)
        assert data['output_ids'][:4] == PREFIX, data
        meta = data['meta_info']
        assert len(meta['output_token_logprobs']) == 5
        assert len(meta['output_token_ids_logprobs']) == 5
        candidates = meta['output_token_ids_logprobs'][4]
        assert [entry[1] for entry in candidates] == labels
        values = [entry[0] for entry in candidates]
        assert all(math.isfinite(value) and value <= 1e-6 for value in values)
        weights = np.exp(np.array(values) - max(values))
        probabilities = (weights / weights.sum()).tolist()
        distribution(probabilities)
        record = {'dataset':row['dataset'], 'id':row['id'], 'latency_s':time.perf_counter()-start,
                  'prompt':prompt, 'label_ids':labels, 'response':data, 'probabilities':probabilities}
        records.append(record)
        print('PASS raw scores', row['dataset'], row['id'], flush=True)
    first = records[0]
    plain = post(client, '/generate', {'text':first['prompt'], 'sampling_params':{'max_new_tokens':5,'ignore_eos':True}})
    assert plain['output_ids'] == first['response']['output_ids'], 'Requesting scores changed generated tokens'
    bad = client.post('/generate', json={'text':first['prompt'],'return_logprob':True,'logprob_start_len':0,'sampling_params':{'max_new_tokens':5}})
    assert bad.status_code == 400, bad.text
    (output / 'raw-smoke.json').write_text(json.dumps({'passed':True,'records':records,'negative_status':bad.status_code},indent=2))

def benchmark(client, output, selected_datasets):
    rows = [r for r in cases() if r['dataset'] in selected_datasets]
    results = []
    with (output / 'predictions.jsonl').open('x') as out:
        for index, row in enumerate(rows, 1):
            body = {'model':MODEL,'state':row['state'],'questions':{'decision':row['question']}}
            if row.get('image'): body['images'] = [image_url(Path(row['image']))]
            start = time.perf_counter()
            record = {key:row[key] for key in ('dataset','id','expected')}
            response = client.post('/v1/systemone', json=body)
            record.update(latency_s=time.perf_counter()-start, status=response.status_code)
            if response.status_code == 200:
                data = response.json()
                answer = data['answers']['decision']
                assert data['usage']['output_tokens'] == 0
                if answer['type'] == 'noul':
                    probabilities = {'no':1-answer['noul'],'yes':answer['noul']}
                else: probabilities = answer['probabilities']
                distribution(list(probabilities.values()))
                prediction = max(probabilities, key=probabilities.get)
                assert set(probabilities) == set(row['labels']), (row, probabilities)
                if answer['type'] == 'choice': assert prediction == answer['choice']
                if answer['type'] == 'score':
                    assert math.isclose(answer['score'],sum(int(k)*p for k,p in probabilities.items()),abs_tol=1e-5)
                assert 0 <= answer['x_label_mass'] <= 1.00001
                record.update(valid=True, correct=prediction==str(row['expected']), prediction=prediction, response=data)
            else:
                record.update(valid=False,correct=False,error=response.text[:2000])
            out.write(json.dumps(record,ensure_ascii=False)+'\n')
            out.flush()
            results.append(record)
            if index % 10 == 0 or index == len(rows):
                print(f'{index}/{len(rows)} valid={sum(r["valid"] for r in results)} correct={sum(r["correct"] for r in results)}',flush=True)
            if len(results)>=3 and all(not r['valid'] for r in results[-3:]):
                raise RuntimeError('Three consecutive request failures; investigate before continuing')
    summary = {}
    for dataset in selected_datasets:
        group = [r for r in results if r['dataset']==dataset]
        if not group: continue
        summary[dataset] = {'count':len(group),'valid':sum(r['valid'] for r in group),'correct':sum(r['correct'] for r in group),
                            'accuracy':sum(r['correct'] for r in group)/len(group),
                            'latency_p50_p95_s':np.percentile([r['latency_s'] for r in group],[50,95]).tolist()}
    (output / 'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode',choices=['raw','benchmark','data'])
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    parser.add_argument('--datasets',nargs='+',default=['jevbench','emojify','tweeteval','flowers'])
    args = parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if args.mode == 'data':
        print(Counter(row['dataset'] for row in cases()))
    else:
        with httpx.Client(base_url='http://127.0.0.1:30000',timeout=300) as client:
            if args.mode == 'raw': raw_smoke(client,args.output)
            else: benchmark(client,args.output,args.datasets)
