import json
import os
from pathlib import Path
import sys
import time
import httpx

root=Path(__file__).resolve().parent
name=sys.argv[1]
pid=json.loads((root/(name+'-launch.json')).read_text())['pid']
for _ in range(180):
    os.kill(pid,0)
    try:
        if httpx.get('http://127.0.0.1:30000/health',timeout=2).status_code==200:
            print(name+' ready',flush=True)
            break
    except httpx.HTTPError:
        pass
    time.sleep(5)
else:
    raise RuntimeError(name+' did not become ready in 15 minutes')
