"""Reproduce rejected native requests and inspect their full denoised canvas."""
import importlib.util,json,pathlib,sys,httpx
from transformers import AutoTokenizer
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));from verify import cases,MODEL
spec=importlib.util.spec_from_file_location('fixtures','/home/ubuntu/sglang/test/registered/unit/entrypoints/openai/test_serving_decisions.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
from sglang.srt.dllm.config import DllmConfig
from sglang.srt.entrypoints.systemone.protocol import SystemOneRequest
from sglang.srt.entrypoints.systemone.serving import SystemOneServing
T=AutoTokenizer.from_pretrained('/home/ubuntu/models/diffusiongemma-26B-A4B-it')
manager=mod.ScoringManager(T,dllm_algorithm='Gemma4Renoise',context_len=8192)
manager.dllm_scoring_config=DllmConfig('Gemma4Renoise',{},256,-1,1,requires_separate_context_encoding=True)
handler=mod._handler(manager,serving_class=SystemOneServing)
failed={x['id'] for x in json.loads((ROOT/'publish/failures.json').read_text())}
records=[]
with httpx.Client(base_url='http://127.0.0.1:30000',timeout=300) as c:
 for row in cases():
  if row['id'] not in failed:continue
  body={'model':MODEL,'state':row['state'],'questions':{'decision':row['question']}}
  response=c.post('/v1/systemone',json=body)
  request=SystemOneRequest(**body);prompts,labels=mod._encoded(handler,request)
  record={'id':row['id'],'expected':row['expected'],'request':body,'status':response.status_code,'response':response.json(),'prompt_ids':prompts[0],'label_ids':labels[0],'prompt':T.decode(prompts[0]),'raw':{}}
  for length in [5,64,256]:
   r=c.post('/generate',json={'input_ids':prompts[0],'sampling_params':{'max_new_tokens':length,'ignore_eos':True},'return_logprob':True,'token_ids_logprob':labels[0]});r.raise_for_status();data=r.json();record['raw'][str(length)]=data
   print(row['id'][:12],'status',response.status_code,'length',length,'prefix',data['output_ids'][:12],'decoded',repr(T.decode(data['output_ids'],skip_special_tokens=False)[:400]),flush=True)
  records.append(record)
(ROOT/'tweeteval-debug/reproduction.json').write_text(json.dumps(records,indent=2,ensure_ascii=False))
print('Saved full raw outputs',flush=True)
