import json,os,pathlib,subprocess,sys
root=pathlib.Path('/home/ubuntu/diffusiongemma-e2e');name=sys.argv[1];config=json.loads(sys.argv[2]);path=root/'tweeteval-debug'/f'{name}-config.json';path.write_text(json.dumps(config))
cmd=json.loads((root/'tweeteval-eager-launch.json').read_text())['command'];cmd[cmd.index('--dllm-algorithm-config')+1]=str(path)
env=dict(os.environ,PYTHONPATH='/home/ubuntu/sglang/python',PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',SGLANG_ENABLE_HEALTH_ENDPOINT_GENERATION='0');env['PATH']=str(root/'venv/bin')+':'+env['PATH']
with (root/'logs'/f'{name}-server.txt').open('w') as log:p=subprocess.Popen(cmd,env=env,cwd='/home/ubuntu/sglang',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record={'pid':p.pid,'command':cmd,'config':config,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/ubuntu/sglang',text=True).strip()};(root/f'{name}-launch.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
