import json,sys,pathlib,httpx,math
root=pathlib.Path('/home/ubuntu/diffusiongemma-e2e');name=sys.argv[1];rows=json.loads((root/'tweeteval-debug/reproduction.json').read_text());results=[]
with httpx.Client(base_url='http://127.0.0.1:30000',timeout=300) as client:
 for r in rows:
  body={'input_ids':r['prompt_ids'],'sampling_params':{'max_new_tokens':8,'ignore_eos':True}}
  plain=client.post('/generate',json=body);plain.raise_for_status();plain=plain.json()
  scored=client.post('/generate',json=dict(body,return_logprob=True,token_ids_logprob=[101,1,1018]));scored.raise_for_status();scored=scored.json()
  status=client.post('/v1/systemone',json=r['request'])
  record={'id':r['id'],'variant':name,'status':status.status_code,'prefix':scored['output_ids'][:4],'plain_prefix':plain['output_ids'][:4],'plain_equals_scored':plain['output_ids']==scored['output_ids'],'matches_original':scored['output_ids'][:5]==r['raw']['5']['output_ids'],'position3_marker_logprobs':scored['meta_info']['output_token_ids_logprobs'][3],'selected_logprobs':scored['meta_info']['output_token_logprobs'][:5]}
  print(json.dumps(record),flush=True);results.append(record)
(root/f'tweeteval-debug/{name}.json').write_text(json.dumps(results,indent=2))
