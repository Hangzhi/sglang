import json,pathlib,httpx
root=pathlib.Path('/home/ubuntu/diffusiongemma-e2e/tweeteval-debug');records=[]
with httpx.Client(base_url='http://127.0.0.1:30000',timeout=300) as c:
 for row in json.loads((root/'reproduction.json').read_text()):
  r=c.post('/generate',json={'input_ids':row['prompt_ids'],'sampling_params':{'max_new_tokens':8,'ignore_eos':True}});r.raise_for_status();data=r.json()
  record={'id':row['id'],'base_commit':'20c49f12c9a1261ea0ba9b5a2b206613661494f0','prefix':data['output_ids'][:4],'output_ids':data['output_ids'],'matches_pr_output':data['output_ids'][:5]==row['raw']['5']['output_ids'],'response':data};records.append(record)
  print(row['id'][:12],record['prefix'],'matches PR:',record['matches_pr_output'],flush=True)
(root/'baseline.json').write_text(json.dumps(records,indent=2))
