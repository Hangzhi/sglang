"""Exercise shared dLLM run/finalize loops with non-Gemma algorithms on CPU."""
import json
from types import SimpleNamespace
from pathlib import Path
import torch
from sglang.srt.dllm.algorithm import get_algorithm
from sglang.srt.dllm.config import DllmConfig

class Runner:
    def __init__(self):self.inputs=[]
    def forward(self,batch,pp_proxy_tensors=None):
        self.inputs.append(batch.input_ids.clone())
        logits=torch.full((8,10),-40.0)
        logits[torch.arange(8),torch.tensor([8,6,7,8,8,8,6,7])]=40
        return SimpleNamespace(logits_output=SimpleNamespace(full_logits=logits),can_run_graph=False)

records=[]
for name in ['LowConfidence','JointThreshold','JointThresholdInDel']:
 for fdfo in [False,True]:
    config=DllmConfig(name,{'max_post_edit_steps':0},4,0,2,first_done_first_out_mode=fdfo,delete_token_id=1,split_token_id=2)
    algorithm=get_algorithm(config);runner=Runner();batch=SimpleNamespace(batch_size=2,input_ids=torch.tensor([3,0,0,0,4,5,0,0]))
    expected=[[3,6,7,8],[4,5,6,7]]
    if fdfo:
        states=None;observed=[]
        for _ in range(8):
            out,tokens,lengths,states,_=algorithm.run(runner,batch,states);observed.append(lengths)
            if all(lengths):break
        assert lengths==[4,4] and states==[None,None]
        assert tokens==expected,(name,tokens)
        assert all(lengths==[0,0] for lengths in observed[:-1])
    else:
        out,tokens,lengths,states,_=algorithm.run(runner,batch)
        assert [x.tolist() for x in tokens]==[[6,7,8],[6,7]]
    assert batch.input_ids.view(2,4).tolist()==expected
    assert runner.inputs[-1].view(2,4).tolist()==expected,'Returned before final tokens were committed to KV'
    assert not hasattr(out,'next_token_logprobs'),'Gemma-specific logprobs leaked to another algorithm'
    record={'algorithm':name,'fdfo':fdfo,'passed':True,'forwards':len(runner.inputs)};records.append(record);print(json.dumps(record),flush=True)
Path(__file__).with_name('other-algorithms.json').write_text(json.dumps(records,indent=2))
